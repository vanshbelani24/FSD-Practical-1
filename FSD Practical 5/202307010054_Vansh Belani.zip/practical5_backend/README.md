
# Practical 5 Backend

Simple Express backend for products, users, cart, and orders with validation and error handling.

## Setup

1. Run `npm install`
2. Run `npm start`
3. Test endpoints like `GET /api/products`, `POST /api/users`, etc.
